# Supplementary Data 1

This archive supports the preprint “Cell-context matching improves AlphaGenome prioritization of experimentally active regulatory variants.”

## Contents

- `Supplementary_Tables/`: machine-readable Supplementary Tables S1-S9. Tables S8-S9 report post hoc controls.

## Access boundary

This is the minimum preprint supplement. The complete reproducibility package is reserved for the journal submission. Raw AlphaGenome Atlas/API outputs, the local prediction cache and credentials are excluded. Source MPRA and ADASTRA data remain available from their cited providers.
